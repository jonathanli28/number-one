package edu.virginia.cs2110.zl3kh.hello;

import android.location.Location;

public class Money {
	
	private Location location;
	private int value;
	
	
	public Money(GPSTracker gps)
	{
		
	}
	
	public boolean TapOnMoney(double TapLong, double UserLat)
	{
		return false;
	}

}

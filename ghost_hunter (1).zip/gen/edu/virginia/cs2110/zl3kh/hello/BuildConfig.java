/** Automatically generated file. DO NOT MODIFY */
package edu.virginia.cs2110.zl3kh.hello;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}